package com.sudha.pdfchat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IntelligentPdfRagApplication {
    public static void main(String[] args) {
        SpringApplication.run(IntelligentPdfRagApplication.class, args);
    }
}
