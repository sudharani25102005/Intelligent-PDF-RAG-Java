package com.sudha.pdfchat;

import org.apache.pdfbox.Loader;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

@Service
public class RagService {

    private static final int CHUNK_SIZE = 1000;
    private static final int OVERLAP = 200;
    private static final int TOP_K = 3;

    private final GeminiService gemini;
    private final List<StoredChunk> index = new ArrayList<>();

    public RagService(GeminiService gemini) {
        this.gemini = gemini;
    }

    public synchronized int indexPdf(byte[] bytes) throws IOException {
        index.clear();

        try (PDDocument doc = Loader.loadPDF(bytes)) {
            PDFTextStripper stripper = new PDFTextStripper();

            for (int page = 1; page <= doc.getNumberOfPages(); page++) {
                stripper.setStartPage(page);
                stripper.setEndPage(page);

                String text = stripper.getText(doc).trim();

                if (text.isBlank()) {
                    continue;
                }

                for (String chunk : split(text)) {
                    index.add(new StoredChunk(
                            new Chunk(chunk, page),
                            gemini.embed(chunk)
                    ));
                }
            }
        }

        return index.size();
    }

    public synchronized Answer ask(String question) {
        if (index.isEmpty()) {
            throw new IllegalStateException("Upload a PDF first.");
        }

        List<Double> query = gemini.embed(question);

        List<Match> matches = index.stream()
                .map(c -> new Match(c, cosine(query, c.vector())))
                .sorted(Comparator.comparingDouble(Match::score).reversed())
                .limit(TOP_K)
                .toList();

        StringBuilder context = new StringBuilder();

        for (Match m : matches) {
            context.append("Page ")
                    .append(m.chunk().pageNumber())
                    .append(":\n")
                    .append(m.chunk().text())
                    .append("\n\n");
        }

        String answer = gemini.generate(context.toString(), question);

        List<Integer> pages = matches.stream()
                .map(m -> m.chunk().pageNumber())
                .distinct()
                .toList();

        return new Answer(answer, pages);
    }

    private List<String> split(String text) {
        List<String> result = new ArrayList<>();
        int start = 0;

        while (start < text.length()) {
            int end = Math.min(start + CHUNK_SIZE, text.length());

            String chunk = text.substring(start, end).trim();

            if (!chunk.isBlank()) {
                result.add(chunk);
            }

            if (end == text.length()) {
                break;
            }

            start = end - OVERLAP;
        }

        return result;
    }

    private double cosine(List<Double> a, List<Double> b) {
        if (a.size() != b.size()) {
            throw new IllegalArgumentException("Embedding dimensions differ.");
        }

        double dot = 0;
        double aa = 0;
        double bb = 0;

        for (int i = 0; i < a.size(); i++) {
            dot += a.get(i) * b.get(i);
            aa += a.get(i) * a.get(i);
            bb += b.get(i) * b.get(i);
        }

        if (aa == 0 || bb == 0) {
            return 0;
        }

        return dot / (Math.sqrt(aa) * Math.sqrt(bb));
    }

    private record StoredChunk(Chunk chunk, List<Double> vector) {}

    private record Match(StoredChunk stored, double score) {
        Chunk chunk() {
            return stored.chunk();
        }
    }

    public record Answer(String answer, List<Integer> pages) {}
}
