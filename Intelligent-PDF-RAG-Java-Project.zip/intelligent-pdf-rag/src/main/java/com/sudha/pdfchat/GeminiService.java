package com.sudha.pdfchat;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.List;

@Service
public class GeminiService {

    private static final String BASE =
            "https://generativelanguage.googleapis.com/v1beta/models/";

    private final ObjectMapper mapper;
    private final HttpClient client = HttpClient.newHttpClient();

    @Value("${gemini.api-key:}")
    private String apiKey;

    public GeminiService(ObjectMapper mapper) {
        this.mapper = mapper;
    }

    public List<Double> embed(String text) {
        requireKey();

        ObjectNode body = mapper.createObjectNode();
        body.put("model", "models/gemini-embedding-001");

        ObjectNode content = body.putObject("content");
        ArrayNode parts = content.putArray("parts");
        parts.addObject().put("text", text);

        JsonNode response = post(
                BASE + "gemini-embedding-001:embedContent",
                body
        );

        JsonNode values = response.path("embedding").path("values");

        if (!values.isArray()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Embedding API returned no vector."
            );
        }

        List<Double> result = new ArrayList<>();
        values.forEach(v -> result.add(v.asDouble()));
        return result;
    }

    public String generate(String context, String question) {
        requireKey();

        String prompt =
                "You are an intelligent PDF assistant.\n" +
                "Answer ONLY from the supplied PDF context.\n" +
                "If the answer is not in the context, say: " +
                ""I could not find this information in the uploaded PDF."\n\n" +
                "PDF CONTEXT:\n" + context +
                "\n\nQUESTION:\n" + question;

        ObjectNode body = mapper.createObjectNode();
        ArrayNode contents = body.putArray("contents");
        ObjectNode content = contents.addObject();
        ArrayNode parts = content.putArray("parts");
        parts.addObject().put("text", prompt);

        JsonNode response = post(
                BASE + "gemini-2.5-flash:generateContent",
                body
        );

        JsonNode text = response.path("candidates")
                .path(0)
                .path("content")
                .path("parts")
                .path(0)
                .path("text");

        if (text.isMissingNode()) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Generation API returned no answer."
            );
        }

        return text.asText();
    }

    private JsonNode post(String url, JsonNode body) {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url + "?key=" + apiKey))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(
                            mapper.writeValueAsString(body)
                    ))
                    .build();

            HttpResponse<String> response = client.send(
                    request,
                    HttpResponse.BodyHandlers.ofString()
            );

            if (response.statusCode() < 200 || response.statusCode() >= 300) {
                throw new ResponseStatusException(
                        HttpStatus.BAD_GATEWAY,
                        "Gemini API error: HTTP " + response.statusCode()
                );
            }

            return mapper.readTree(response.body());

        } catch (ResponseStatusException e) {
            throw e;
        } catch (Exception e) {
            throw new ResponseStatusException(
                    HttpStatus.BAD_GATEWAY,
                    "Could not contact Gemini API.",
                    e
            );
        }
    }

    private void requireKey() {
        if (apiKey == null || apiKey.isBlank()) {
            throw new ResponseStatusException(
                    HttpStatus.INTERNAL_SERVER_ERROR,
                    "GEMINI_API_KEY is not configured."
            );
        }
    }
}
