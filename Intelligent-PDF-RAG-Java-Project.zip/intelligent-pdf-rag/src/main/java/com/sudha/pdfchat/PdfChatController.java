package com.sudha.pdfchat;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class PdfChatController {

    private final RagService rag;

    public PdfChatController(RagService rag) {
        this.rag = rag;
    }

    @PostMapping(value = "/upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public UploadResponse upload(@RequestParam("file") MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            throw new IllegalArgumentException("Please upload a PDF.");
        }

        String name = file.getOriginalFilename();
        if (name == null || !name.toLowerCase().endsWith(".pdf")) {
            throw new IllegalArgumentException("Only PDF files are supported.");
        }

        int chunks = rag.indexPdf(file.getBytes());

        return new UploadResponse(
                "PDF indexed successfully.",
                name,
                chunks
        );
    }

    @PostMapping("/ask")
    public AskResponse ask(@RequestBody AskRequest request) {
        if (request.question() == null || request.question().isBlank()) {
            throw new IllegalArgumentException("Question cannot be empty.");
        }

        RagService.Answer result = rag.ask(request.question());

        return new AskResponse(result.answer(), result.pages());
    }

    public record AskRequest(String question) {}

    public record AskResponse(String answer, List<Integer> pages) {}

    public record UploadResponse(String message, String fileName, int chunks) {}
}
