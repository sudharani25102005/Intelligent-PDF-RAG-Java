package com.sudha.pdfchat;

public record Chunk(String text, int pageNumber) {}
