# Intelligent PDF Chat Assistant Using RAG

**Submitted By:** Yadala Sudha Rani  
**Roll No:** 23102A040663

## Technologies
- Java 17
- Spring Boot 3.5.4
- Apache PDFBox 3.0.5
- Gemini API
- Maven

## Project Flow
PDF Upload -> Text Extraction -> Chunking -> Embeddings -> Cosine Similarity -> Top-3 Retrieval -> Gemini -> Answer + Source Pages

## Requirements
- JDK 17+
- Maven
- Gemini API key

## Configure Gemini API Key

Windows PowerShell:

```powershell
$env:GEMINI_API_KEY="YOUR_API_KEY"
```

Do not commit the API key to GitHub.

## Run

```powershell
mvn clean package
mvn spring-boot:run
```

Server:
`http://localhost:8080`

## API

### Upload PDF
`POST /api/upload`

Multipart field:
`file`

### Ask a Question
`POST /api/ask`

JSON:
```json
{
  "question": "What is the main topic?"
}
```

## Author
Yadala Sudha Rani
